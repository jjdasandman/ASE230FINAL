<?php
function readJSON($filename) {
    // Read JSON file and decode its content into an associative array
    $content = file_get_contents($filename);
    $data = json_decode($content, true);
    return $data;
}
?>