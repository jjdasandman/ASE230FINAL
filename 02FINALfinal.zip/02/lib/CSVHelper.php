<?php
class CSVHelper {
    private static $csvFilePath = __DIR__ . '/../data/navbar.csv';

    public static function readCSV() {
        // Read CSV file and parse its content into an array
        $data = [];
        if (($handle = fopen(self::$csvFilePath, "r")) !== FALSE) {
            while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $data[] = $row;
            }
            fclose($handle);
        }
        return $data;
    }

    public static function createEntry($section, $link) {
        // Add a new entry to the CSV file
        $file = fopen(self::$csvFilePath, 'a');
        if ($file) {
            fputcsv($file, [$section, $link]);
            fclose($file);
        }
    }

    public static function updateEntry($section, $newSection, $newLink) {
		// Update the section and link for a specific entry in the CSV file
		$data = self::readCSV();
		foreach ($data as &$row) {
			if ($row[0] === $section) {
				$row[0] = $newSection;
				$row[1] = $newLink;
				break;
			}
		}
		// Write the updated data back to the CSV file
		self::writeCSV($data);
	}

    public static function deleteEntry($section) {
        // Delete an entry based on the section from the CSV file
        $data = self::readCSV();
        foreach ($data as $key => $row) {
            if ($row[0] === $section) {
                unset($data[$key]);
                break;
            }
        }
        // Write the updated data back to the CSV file
        self::writeCSV($data);
    }

    private static function writeCSV($data) {
        $file = fopen(self::$csvFilePath, 'w');
        if ($file) {
            foreach ($data as $row) {
                fputcsv($file, $row);
            }
            fclose($file);
        }
    }
}
?>