<?php 


Include_once "db_connection.php";

	
?>

<!DOCTYPE html>
<html>
<head>
	<title>My website</title>
</head>
<body>
	
	<!-- $conn = SELECT * FROM pages -->
	
	<h1>This is the index page</h1>
	
	<?php
	$items = array();
	/* echo "reading Query...". "<br>". "<br>";
	$q = $conn->query('SELECT title FROM pages');
	while ($row = $q->fetch())
	{
	echo $row['title'] . "<br>";
	} */
	$requestedSection = "home";
	echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT title, content FROM pages WHERE Title = :requestedSection');
	$q->execute([':requestedSection' => $requestedSection]);
	while ($row = $q->fetch())
	{
	echo $row['title'] . "<br>";
	echo $row['content'] . "<br>";

	$items[] = $row['title']; //this and 
	array_push($items, $row['content']); //this do the same thing; appending to the array
	
	}
	echo '<pre>'; 
	print_r($items); 
	echo '</pre>';
	?>

	<br>
	
	<?php
	echo "inserting...". "<br>";

	$insertQuery = $conn->prepare("INSERT INTO pages (PageID, Title, Content, UserID) VALUES (:PageID, :Title, :Content, :UserID)");
	$insertQuery->bindParam(':PageID', $PageID);
	$insertQuery->bindParam(':Title', $Title);
	$insertQuery->bindParam(':Content', $Content);
	$insertQuery->bindParam(':UserID', $UserID);
	// insert one row
	$PageID = '12';
	$Title = "Test4";
	$Content ="#Test4";
	$UserID = "3"; 
	$insertQuery->execute();
	
	echo "Insertion Complete.". "<br>". "<br>";
	
	$q = $conn->query('SELECT title FROM pages');
	while ($row = $q->fetch())
	{
	echo $row['title'] . "<br>";
	}
	
	echo "<br>" . "deleting query..." . "<br>";
	
	$deleteQuery = $conn->prepare("DELETE FROM pages WHERE PageID = :PageID");
	//DELETE FROM pages WHERE `pages`.`PageID` = 0
	$deleteQuery->bindParam(':PageID', $PageID);
	// delete one row
	$PageID = '12';
	$deleteQuery->execute();
	
	echo "Query deleted." . "<br>" . "<br>";
	
	$q = $conn->query('SELECT title FROM pages');
	while ($row = $q->fetch())
	{
	echo $row['title'] . "<br>";
	}
	
	echo "<br>" . "updating query..." . "<br>";
	
	$updateQuery = $conn->prepare("UPDATE pages SET Title = 'Test32', Content = '#Test32' WHERE PageID = :PageID");
	//UPDATE `pages` SET `Title` = 'Test31', `Content` = '#Test31' WHERE `pages`.`PageID` = 9;
	$updateQuery->bindParam(':PageID', $PageID);
	// delete one row
	$PageID = '9';
	$updateQuery->execute();
	
	echo "update complete" . "<br>" . "<br>";
	
	$q = $conn->query('SELECT title FROM pages');
	while ($row = $q->fetch())
	{
	echo $row['title'] . "<br>";
	}
	
	
	
	
	?>
</body>
</html>