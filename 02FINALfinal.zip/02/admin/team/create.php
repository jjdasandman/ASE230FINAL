<?php
//echo "you landed on the create page";

// Include any necessary files and functions
include '../../lib/db_connection.php';
$items = array();

// Check if the form is submitted  //TeamID, MemberName, Role, Bio, Pic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $name1 = $_POST['name1'];
	echo "name: " . $name1. "<br>";
    $description1 = $_POST['description1'];
	echo "description: " . $description1. "<br>";
    $application1 = $_POST['application1'];
	echo "application: " . $application1. "<br>";
	$icon1 = $_POST['icon1'];
	echo "icon: " . $icon1. "<br>";

    // Validate the form fields (you can add more validation as needed)
    if (empty($name1) || empty($description1) || empty($application1) || empty($icon1)) {
        echo 'All fields are required.';
        exit; // Terminate the script
    }

    //echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT TeamID FROM team');
	$q->execute();
	while ($row = $q->fetch())
	{
	$items[] = $row['TeamID']; //this and 
	
	}
	$appendToID = max($items) + 1;
	echo "Append to ID: " . $appendToID . "<br>";
	echo "inserting...". "<br>";
	$name = $name1;
	$role = $description1;
	$bio = $application1;
	$pic = $icon1; 
	$id;	//TeamID, MemberName, Role, Bio, Pic
	$q = $conn->prepare("INSERT INTO team (TeamID, MemberName, Role, Bio, Pic) VALUES (:id, :name, :role, :bio, :pic)");
	$q->bindParam(':id', $appendToID);
	$q->bindParam(':name', $name);
	$q->bindParam(':role', $role); 
	$q->bindParam(':bio', $bio);
	$q->bindParam(':pic', $pic);
	$ProductID = $appendToID;

	$q->execute();
	//echo "Insertion Complete.". "<br>". "<br>";
    
	
    // Redirect the user to the edit page for the newly created item
    header('Location: index.php');
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Item</title>
</head>
<body>
     <h1>Create New Item</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new item -->
        <label for="name">Name:</label>
        <input type="text" name="name1" id="name1" required>

        <label for="description">Description:</label>
        <textarea name="description1" id="description1" required></textarea>

        <label for="application">Application:</label>
        <textarea name="application1" id="application1" required></textarea>
		
        <label for="icon">Icon:</label>
        <input type="text" name="icon1" id="icon1" required>

        <input type="submit" value="Create Item">
    </form>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>