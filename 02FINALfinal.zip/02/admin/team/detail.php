<?php
//TEAM detail
// Include any necessary files and functions
include '../../lib/db_connection.php';
$product = array();
$ProductID;
$id;

if (isset($_GET['id'])) {
    
	//echo "ID: " . $id . "<br>";
	//echo "reading Query...". "<br>". "<br>"; 
	$id = $_GET['id'];    //TeamID, MemberName, Role, Bio, Pic
	$q =  $conn->prepare('SELECT TeamID, MemberName, Role, Bio, Pic FROM team WHERE TeamID = :id');
	//$q->bindParam(':ProductID', $ProductID);
	$q->execute([':id' => $id]);
	while ($row = $q->fetch())
	{
		$product[] = $row;
	}

	$itemFound = false;
        foreach ($product as $item) {
            if ($item['TeamID'] == $id) {
                $itemFound = true;
                //echo '<h2>' . htmlspecialchars($item['Name']) . '</h2>';
                //echo '<p>Item Link: <a href="' . htmlspecialchars($item['ProductID']) . '">' . htmlspecialchars($item['ProductID']) . '</a></p>';
                //echo '<p><a href="edit.php?section=' . urlencode($item['Name']) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item['Name']) . '">Delete</a></p>';
                break; // Exit the loop once the item is found
            }
        }
	
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Team Details</title>
</head>
<body>
    <h1>Team Details</h1>
    <?php
	//images/team/img-1.jpg
	//echo '<img src="../../images/team/img-1.jpg">';
    // Check if a specific item is requested (e.g., based on query parameters)
    /* if (isset($_GET['section'])) {
        $requestedSection = $_GET['section'];

        // Find and display the details of the requested item
        $itemFound = false;
        foreach ($data as $item) {
            if ($item[0] === $requestedSection) {
                $itemFound = true;
                echo '<h2>' . htmlspecialchars($item[0]) . '</h2>';
                echo '<p>Title: ' . htmlspecialchars($item[1]) . '</p>';
                echo '<p>Background: ' . htmlspecialchars($item[2]) . '</p>';
				//echo '<img src="../../' . htmlspecialchars($item[3]) . '" alt="' . htmlspecialchars($item[0]) . '" width="100" height="100">';
				//echo '<p>Image src: '.'../..'. htmlspecialchars($item[3]). '</p>';
				//. '" alt="' . htmlspecialchars($item[0]) .
                echo '<p><a href="edit.php?section=' . urlencode($item[0]) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item[0]) . '">Delete</a></p>';
                break; // Exit the loop once the item is found
            }
        }

        if (!$itemFound) {
            echo '<p>Item not found.</p>';
        }
    } else {
        echo '<p>No item selected.</p>';
    } */  //TeamID, MemberName, Role, Bio, Pic
	if (isset($product)) { ?>
        <h2>Name: <?= $product[0]['MemberName'] ?></h2>
        <p>Role: <?= $product[0]['Role'] ?></p>
        <p>Bio: <?= $product[0]['Bio'] ?></p>
		<p>Pic address: <?= $product[0]['Pic'] ?></p>

        <!-- Edit and Delete buttons -->
        <form method="post" action="edit.php?id=<?= $product[0]['TeamID'] ?>">
            <button type="submit">Edit</button>
        </form>

        <form method="post" action="delete.php?id=<?= $product[0]['TeamID'] ?>">
            <button type="submit">Delete</button>
        </form>
    <?php } else { ?>
        <p>Product uh not foundddddd.</p>
    <?php } ?>
	
    <p><a href="index.php">Back to team List</a></p>
</body>
</html>