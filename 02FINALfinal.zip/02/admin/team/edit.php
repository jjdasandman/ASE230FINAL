<?php
// Include any necessary files and functions

// Check if the product ID is provided in the query parameters
//
include '../../lib/db_connection.php';
$product = array();
	
// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['id'])) {
    $id = $_GET['id'];		//TeamID, MemberName, Role, Bio, Pic
	$q =  $conn->prepare('SELECT TeamID, MemberName, Role, Bio, Pic FROM team WHERE TeamID = :id');
	$q->execute([':id' => $id]);
	while ($row = $q->fetch())
	{
		$product[] = $row;
	}
	echo '<pre>'; 
	print_r($product); 
	echo '</pre>';
}
    // Check if the form is submitted          //TeamID, MemberName, Role, Bio, Pic
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
		// Retrieve the product ID
		$TeamID = $_POST['id'];
		echo 'TeamID: ' . $TeamID. "<br>";
		$updatedName = $_POST['MemberName'];
		echo 'updatedName: ' . $updatedName. "<br>";
		$updatedRole = $_POST['Role'];
		echo 'updatedRole: ' . $updatedRole. "<br>";
		$updatedBio = $_POST['Bio'];
		echo 'updatedBio: ' . $updatedBio. "<br>";
		$updatedPic = $_POST['Pic'];
		echo 'updatedPic: ' . $updatedPic. "<br>";
		// Retrieve and update the product details
		echo 'product[0][TeamID]: ' . $product[0]['TeamID']. "<br>";
		//echo "<br>" . "updating query..." . "<br>";
		
		$updateQuery = $conn->prepare("UPDATE team SET MemberName = :updatedName, Role = :updatedRole, Bio = :updatedBio, pic = :updatedPic WHERE TeamID = :ProductID");
		//UPDATE `pages` SET `Title` = 'Test31', `Content` = '#Test31' WHERE `pages`.`PageID` = 9;
		$updateQuery->bindParam(':updatedName', $updatedName);
		$updateQuery->bindParam(':updatedRole', $updatedRole);
		$updateQuery->bindParam(':updatedBio', $updatedBio);
		$updateQuery->bindParam(':updatedPic', $updatedPic);
		$updateQuery->bindParam(':ProductID', $ProductID);
		$ProductID = $id;

		//$PageID = $items[2];
		//$productId = $product[0][0];
		$updateQuery->execute(); 
		
		header("Location: detail.php?id=" . urlencode($_POST['id']));
		exit;
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Team Member</title>
</head>
<body>
    <h1>Edit Team Member</h1>

    <?php if ($product) {                                   //TeamID, MemberName, Role, Bio, Pic?>
        <form method="POST" action="">
            <!-- Form fields for editing the item -->
			<input type="hidden" name="update" value="true">
            <input type="hidden" name="id" value="<?= $product[0]['TeamID'] ?>">
			
            <label for="name">Name:</label>
            <input type="text" name="MemberName" id="MemberName" value="<?= $product[0]['MemberName'] ?>" required>

            <label for="description">Role:</label>
            <textarea name="Role" id="Role" required><?= $product[0]['Role'] ?></textarea>

            <label for="applications">Bio:</label>
            <textarea name="Bio" id="Bio" required><?= $product[0]['Bio'] ?></textarea>

            <label for="icon">Pic address:</label>
            <input type="text" name="Pic" id="Pic" value="<?= $product[0]['Pic'] ?>" required> <!-- Include the icon input -->

            <input type="submit" value="Save Changes">
        </form>
    <?php } else { ?>
        <p>Product not found</p>
    <?php } ?>

    <p><a href="index.php">Back to Team List</a></p>
</body>
</html>