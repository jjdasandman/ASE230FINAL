<?php
/* TEAM INDEX */
include_once '../../lib/db_connection.php';
$data = array();

echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT TeamID, MemberName, Role, Bio, Pic FROM team');
$q->execute();
while ($row = $q->fetch())
{
	$data[] = $row; //['title']; //this and 
	//array_push($data, $row['content']); //this do the same thing; appending to the array
	
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>TEAM Item List</title>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
    <meta name="keywords" content="bootstrap 5, premium, marketing, multipurpose" />
    <meta content="Themesbrand" name="author" />
    <!-- favicon -->
    <link rel="shortcut icon" href="images/logos/TinyTree.jpg" />

    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <!-- icon -->
    <link href="css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/pe-icon-7-stroke.css" />

    <link href="css/style.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/colors/cyan.css" id="color-opt">
</head>
<body>
    <h1>TEAM List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
				<th>Role</th>
				<th>Bio</th>
				<th>Pic</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Item rows will be generated dynamically here -->
			<?php
				//echo var_dump($data);
				// Include your database connection or data retrieval logic here

				
									//TeamID, MemberName, Role, Bio, Pic
				// Loop through the items and generate table rows
				if (!empty($data)) {
					foreach ($data as $product) { 
						echo '<tr>';
						echo '<td>' . htmlspecialchars($product['MemberName']) . '</td>'; 
						echo '<td>' . htmlspecialchars($product['Role']) . '</td>';
						echo '<td>' . htmlspecialchars($product['Bio']) . '</td>';
						echo '<td>' . htmlspecialchars($product['Pic']) . '</td>';
						echo '<td><a href="detail.php?id=' . urlencode($product['TeamID']) . '">View Details</a></td>';
						// urlencode($_POST['id']))
						echo '</tr>';
					} 
				} 
				else {
					// Handle the case where $data is empty (no CSV data found)
					echo '<tr><td colspan="2">No data found.</td></tr>';
				}
			?>
        </tbody>
    </table>
    <p><a href="create.php">
	<button type="button" class="#">click to create</button>
	</a></p>
	<p><a href="../dashboard.php">
	<button type="button" class="#">return to dashboard</button>
	</a></p>
	<!-- javascript -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/smooth-scroll.polyfills.min.js"></script>
    <script src="js/gumshoe.polyfills.min.js"></script>
    <!-- Main Js -->
    <script src="js/app.js"></script>
</body>
</html>