<?php
//TEAM delete
// Include any necessary files and functions
include '../../lib/db_connection.php';
$items = array();
$id; //id will be the pageID to delete
echo "reading Query...". "<br>". "<br>";  //TeamID, MemberName, Role, Bio, Pic
$q =  $conn->prepare('SELECT TeamID, MemberName FROM team');
$q->execute();
while ($row = $q->fetch()){
	$items[] = $row; //this do the same thing; appending to the array
}

if (isset($_GET['id'])) {
	
    $requestedId = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		//echo 'uhhhh';
        if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
			//echo "INTHEIFFFFF";
            // Read the contents of the CSV file into an array
            foreach($items as $item){
				//echo "INTHEIForrrIFFFF";
				//echo "Team ID: " . $item['TeamID'] ."; looking for ID:" . $requestedId . "<br>";
				//echo "item[TeamID]: " . $item['TeamID'] . "<br>";
				if($item['TeamID'] == $requestedId){
				$id = $item['TeamID']; //setting the pageID of the sections that matches
				//echo "identified ProductID: " . $id . "<br>";

			}
		}
			
        //echo "<br>" . "deleting query..." . "<br>";
	
		$deleteQuery = $conn->prepare("DELETE FROM team WHERE TeamID = :id");
		//DELETE FROM pages WHERE `pages`.`PageID` = 0
		$deleteQuery->bindParam(':id', $id);
		// delete one row
		//$requestedId = $id;
		$deleteQuery->execute();
		
		echo "Query deleted." . "<br>" . "<br>";

		//echo "reading Query...". "<br>". "<br>";  //TeamID, MemberName, Role, Bio, Pic
		$q =  $conn->prepare('SELECT TeamID FROM team');
		$q->execute();
		while ($row = $q->fetch()){
			$items[] = $row; //this do the same thing; appending to the array
		}
		// Redirect the user to the index page
        header('Location: index.php');
        exit; // Terminate the script
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Item</title>
</head>
<body>
    <h1>Delete Item</h1>
    <?php
    if (isset($requestedId)) {
        echo "Are you sure you want to delete the team with ID: $requestedId?";
    ?>
    <form method="post" action="">
        <label for="confirm">Confirm Deletion (type 'yes' to confirm):</label>
        <input type="text" name="confirm" id="confirm">
        <input type="submit" value="Delete">
    </form>
    <?php
    } else {
        echo 'Item not found.';
    }
    ?>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>