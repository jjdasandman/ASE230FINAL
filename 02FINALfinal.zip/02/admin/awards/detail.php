<?php
/* AWARDS DETAIL */

//include '../../lib/JSONHelper.php'; // Include the JSONHelper class file
// Set the JSON file path
//JSONHelper::setJSONFilePath('../../data/awards.json');

// Read the existing data from the JSON file
//$data = JSONHelper::readJSON();
include_once '../../lib/db_connection.php';
$data = array();

echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT year, award, source, icon FROM awards');
$q->execute();
while ($row = $q->fetch())
{
	//echo $row['title'] . "<br>";
	//echo $row['content'] . "<br>";
	$data[] = $row; 
	
}
/* echo "<pre>";
print_r($data);
echo "</pre>"; */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
		$year = $_POST['year'];
		
        $awardName = $_POST['award'];
		
		
        // Redirect to the delete page with the item's year and award as parameters
        header("Location: delete.php?year=$year&award=$awardName");
        exit;
    } elseif (isset($_POST['action']) && $_POST['action'] === 'edit') {
        // Redirect to the edit page
        $year = $_POST['year']; //should change to award name
		$awardName = $_POST['award'];
        header("Location: edit.php?year=$year&award=$awardName");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Award Details</title>
</head>
<body>
    <h1>Award Details</h1>
    <?php
    if (isset($_GET['year']) && isset($_GET['award'])) {

        $year = $_GET['year'];

        $awardName = $_GET['award'];

        if (!empty($data)) {
            foreach ($data as $item) {

                if ($item['year'] == $year && $item['award'] === $awardName) {
					//$item['year'] === $year && $item['award'] === $awardName
                    echo '<p>Year: ' . htmlspecialchars($item['year']) . '</p>';
                    echo '<p>Award: ' . htmlspecialchars($item['award']) . '</p>';
                    echo '<p>Source: ' . htmlspecialchars($item['source']) . '</p>';
                    echo '<p>Icon code: ' . htmlspecialchars($item['icon']) . '</p>';
                    ?>
                    <form method="post" action="">
                        <input type="hidden" name="year" value="<?php echo $year; ?>">
                        <input type="hidden" name="award" value="<?php echo htmlspecialchars($awardName); ?>">
                        <input type="submit" name="action" value="edit" style="margin-right: 10px;">
                        <input type="submit" name="action" value="delete">
                    </form>
                    <?php
                    break;
                }
            }
        }
    } else {
        echo '<p>No award selected.</p>';
    }
    ?>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>