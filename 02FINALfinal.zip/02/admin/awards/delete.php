<?php
/* AWARDS DELETE */

include '../../lib/JSONHelper.php';

// Set the JSON file path
//JSONHelper::setJSONFilePath('../../data/awards.json');
include '../../lib/db_connection.php';
$data = array();
$d; //d will be the pageID to delete
echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT awardID, year, award FROM awards');
	$q->execute();
	while ($row = $q->fetch())
	{
	$data[] = $row; //this do the same thing; appending to the array

	}

// Check if the item should be deleted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
    $year = $_GET['year'];
    $award_name = $_GET['award'];
	
	foreach ($data as $item) {
		if($item['year'] == $year && $item['award'] === $award_name){
			$d = $item['awardID']; //finding the item to remove
			echo "awardID: " . $d . "<br>";
		}
	}
	
	echo "<br>" . "deleting query..." . "<br>";
	
	$deleteQuery = $conn->prepare('DELETE FROM awards WHERE awardID = :d');
	//DELETE FROM pages WHERE `pages`.`PageID` = 0
	$deleteQuery->bindParam(':d', $d);
	// delete one row
	$deleteQuery->execute();
	echo "Query deleted." . "<br>" . "<br>";
	
    // Redirect the user to the index page
    header('Location: index.php');
    exit;
}

// If the user hasn't confirmed the deletion, show the confirmation form
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Award</title>
</head>
<body>
    <h1>Delete Award</h1>
    <p>Are you sure you want to delete this award?</p>
    <form method="post" action="">
        <input type="hidden" name="confirm" value="yes">
        <input type="submit" value="Yes, Delete">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>