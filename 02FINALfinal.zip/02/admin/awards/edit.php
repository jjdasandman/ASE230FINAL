<?php
/* AWARDS EDIT */

//include '../../lib/JSONHelper.php';

// Set the JSON file path
//JSONHelper::setJSONFilePath('../../data/awards.json');
include_once '../../lib/db_connection.php';
$data = array();

echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT awardID, year, award, source, icon FROM awards');
$q->execute();
while ($row = $q->fetch())
{
	//echo $row['title'] . "<br>";
	//echo $row['content'] . "<br>";
	$data[] = $row; 
	
}


// Initialize variables
$editAward = null;

if (isset($_GET['year']) && isset($_GET['award'])) {
    $year = $_GET['year'];
	$awardName = $_GET['award'];

    // Read the existing data from the JSON file
    //$data = JSONHelper::readJSON();

    if (!empty($data)) {
        foreach ($data as $key => $award) {
			//$item['year'] == $year && $item['award'] === $awardName
            if ($award['year'] == $year && $award['award'] === $awardName) {
                $editAward = $award['awardID'];
                $editIndex = $key;
                break;
            }
        }
    }
}
//echo "Year: " . $year . "<br>";
//echo "Award Name: " . $awardName . "<br>";
//echo "Award ID: " . $editAward . "<br>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['year']) && isset($_POST['award']) && isset($_POST['source']) && isset($_POST['icon'])) {
        // Use the updateAward method with the correct number of arguments
        /* JSONHelper::updateAward(
            $editAward['year'],
            $_POST['year'],
            $editAward['award'],
            $_POST['award'],
            $_POST['source'],
            $_POST['icon']
        ); */
		$updateYear = $_POST['year'];
		echo "updated year: " . $updateYear . "<br>";
        $updateAward = $_POST['award'];
		echo "updated award: " . $updateAward . "<br>";
        $updateSource = $_POST['source'];
		echo "updated source: " . $updateSource . "<br>";
        $updateIcon = $_POST['icon'];
		echo "updated icon: " . $updateIcon . "<br>";
		echo "AwardID: " . $editAward . "<br>";
		echo "<br>" . "updating query..." . "<br>";
	
		$updateQuery = $conn->prepare("UPDATE awards SET year = :updateYear, award = :updateAward, source = :updatedSource, icon = :updatedIcon WHERE awardID = :editAward");
		//$q = $conn->prepare('SELECT year, award, source, icon FROM awards');
		$updateQuery->bindParam(':updateYear', $updateYear);
		$updateQuery->bindParam(':updateAward', $updateAward);
		$updateQuery->bindParam(':updatedSource', $updateSource);
		$updateQuery->bindParam(':updatedIcon', $updateIcon);
		$updateQuery->bindParam(':editAward', $data[$editAward]['awardID']);
		
		$updateQuery->execute();
		echo "<br>" . "update complete." . "<br>";
		
		
        // Redirect to the index page
        //header("Location: index.php");
        //exit;
		?> <p><a href="index.php">Back to Item List</a></p> <?php
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Award</title>
</head>
<body>
    <h1>Edit Award</h1>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" value="<?php echo $data[$editIndex]['year']; ?>" required>

        <label for="award">Award:</label>
        <input type="text" name="award" id="award" value="<?php echo $data[$editIndex]['award']; ?>" required>

        <label for="source">Source:</label>
        <input type="text" name="source" id="source" value="<?php echo $data[$editIndex]['source']; ?>" required>

        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon" value="<?php echo $data[$editIndex]['icon']; ?>" required>

        <input type="submit" value="Save Changes">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>