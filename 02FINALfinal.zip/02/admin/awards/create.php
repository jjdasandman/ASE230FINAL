<?php
/* AWARDS CREATE */

//include '../../lib/ReadJSON.php';
include_once '../../lib/db_connection.php';
$data = array();
$appendToID;
echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT awardID, year, award, source, icon FROM awards');
$q->execute();
while ($row = $q->fetch())
{
	$data[] = $row; //this and 
	$appendToID = $row['awardID'];
} 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['year']) && isset($_POST['award']) && isset($_POST['source']) && isset($_POST['icon'])) {
		$year = $_POST['year'];
		$award = $_POST['award'];
		$source =  $_POST['source'];
		$icon = $_POST['icon'];

		echo "reading Query...". "<br>". "<br>"; 
		$q =  $conn->prepare('SELECT awardID FROM awards');
		$q->execute();
		while ($row = $q->fetch())
		{
		$data[] = $row['awardID']; //this and 
		
		}
		echo '<pre>'; 
		print_r($data); 
		echo '</pre>';
		$appendToID = $appendToID + 1; //$data[count($data)]['awardID'] + 1;
		$userID = "3"; 
		echo "Append to ID: " . $appendToID . "<br>";
		echo "inserting...". "<br>";

		$insertQuery = $conn->prepare("INSERT INTO awards (awardID, year, award, source, icon, userID) VALUES (:awardID, :year, :award, :source, :icon, :userID)");
		//UPDATE awards SET year = :updateYear, award = :updateAward, source = :updatedSource, icon = :updatedIcon WHERE awardID = :editAward
		//INSERT INTO pages (PageID, Title, Content, UserID) VALUES (:PageID, :Title, :Content, :UserID)
		$insertQuery->bindParam(':awardID', $appendToID);
		$insertQuery->bindParam(':year', $year);
		$insertQuery->bindParam(':award', $award);
		$insertQuery->bindParam(':source', $source);
		$insertQuery->bindParam(':icon', $icon);
		$insertQuery->bindParam(':userID', $userID);
		// insert one row
		$PageID = $appendToID;
		
		$insertQuery->execute();
		
		echo "Insertion Complete.". "<br>". "<br>";
			header("Location: index.php");
			exit;
	}
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Award</title>
</head>
<body>
    <h1>Create New Award</h1>
    <form method="POST" action="">
        <label for="year">Year:</label>
        <input type="text" name="year" id="year" required>

        <label for="award">Award:</label>
        <input type="text" name="award" id="award" required>

        <label for="source">Source:</label>
        <input type="text" name="source" id="source" required>

        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon" required>
        
        <input type="submit" value="Create Award">
    </form>
    <p><a href="index.php">Back to Awards List</a></p>
</body>
</html>