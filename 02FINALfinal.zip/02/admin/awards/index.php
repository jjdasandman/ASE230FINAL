<?php /* AWARDS INDEX */

//include '../../lib/JSONHelper.php'; // Include the JSONHelper class file
// Set the JSON file path
//JSONHelper::setJSONFilePath('../../data/awards.json');

// Read the existing data from the JSON file
//$data = JSONHelper::readJSON();

include_once '../../lib/db_connection.php';
$data = array();
echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT year, award, source, icon FROM awards');
$q->execute();
while ($row = $q->fetch())
{
	$data[] = $row; //this and 
	//array_push($data, $row['content']); //this do the same thing; appending to the array
	
} 

?>
<!DOCTYPE html>
<html>
<head>
    <title>Awards List</title>
</head>
<body>
    <h1>Awards List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Year</th>
                <th>Award</th>
                <th>Source</th>
				<th>Icon</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Check if the data is an array and contains "awards"
            if (!empty($data)) {
                foreach ($data as $award) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($award['year']) . '</td>';
                    echo '<td>' . htmlspecialchars($award['award']) . '</td>';
                    echo '<td>' . htmlspecialchars($award['source']) . '</td>';
					echo '<td>' . htmlspecialchars($award['icon']) . '</td>';
                    //echo '<td><a href="detail.php?year=' . urlencode($award['year']) . '">View Details</a></td>';
					echo '<td><a href="detail.php?year=' . urlencode($award['year']) . '&award=' . urlencode($award['award']) . '">View Details</a></td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="4">No awards found.</td></tr>';
            }
            ?>
        </tbody>
    </table>
    <p><a href="create.php">Create New Award</a></p>
    <p><a href="../dashboard.php">
        <button type="button" class="#">return to dashboard</button>
    </a></p>
</body>
</html>