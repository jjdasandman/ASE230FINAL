<?php
// Include any necessary files and functions
include '../../lib/ReadCSV.php';

// Check if the contact ID is provided in the query parameters
if (isset($_GET['id'])) {
    $contactId = $_GET['id'];

    // Load contact data from CSV
    $csvFilePath = '../../data/contacts.csv';
    $contactData = ReadCSV($csvFilePath);

    // Check if the requested contact ID is valid
    if (isset($contactData[$contactId])) {
        $contact = $contactData[$contactId];
    } else {
        $contact = null; // Contact not found
    }
} else {
    $contact = null; // No contact ID provided
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Request Details</title>
</head>
<body>
    <h1>Contact Request Details</h1>

    <?php if ($contact) { ?>
        <p>Name: <?= $contact[0] ?></p>
        <p>Email: <?= $contact[1] ?></p>
        <p>Subject: <?= $contact[2] ?></p>
        <p>Comments: <?= $contact[3] ?></p>
    <?php } else { ?>
        <p>Contact not found</p>
    <?php } ?>

    <p><a href="index.php">Back to Contact List</a></p>
</body>
</html>