<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize user input
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password

    // Specify the path to the CSV file
    $csvFilePath = '../data/passwords.csv';

    // Open the CSV file in append mode
    $csvFile = fopen($csvFilePath, 'a');

    // Lock the file for writing
    if (flock($csvFile, LOCK_EX)) {
        // Write the new user data to the CSV file
        $userData = [$username, $password];
        fputcsv($csvFile, $userData);

        // Release the lock
        flock($csvFile, LOCK_UN);

        // Close the file
        fclose($csvFile);
    } else {
        // Handle the case where the file could not be locked (e.g., concurrent access)
        echo 'Unable to register at this time. Please try again later.';
        exit; // Terminate the script
    }

    // Redirect to the login page
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h1>Register</h1>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <input type="submit" value="Register">
    </form>
</body>
</html>