<?php
// Include any necessary files and functions
//include '../../lib/ReadCSV.php';
include '../../lib/db_connection.php';
$product = array();
$ProductID;
$id;
// Retrieve data from your data source (e.g., CSV file)
//$csvFilePath = '../../data/products.csv';

 
// Check if the product ID is provided in the query parameters
if (isset($_GET['id'])) {
    
	//echo "ID: " . $id . "<br>";
	echo "reading Query...". "<br>". "<br>"; 
	$id = $_GET['id'];
	$q =  $conn->prepare('SELECT ProductID, Name, Description, Applications, Icon FROM products WHERE ProductID = :id');
	//$q->bindParam(':ProductID', $ProductID);
	$q->execute([':id' => $id]);
	while ($row = $q->fetch())
	{
		$product[] = $row;
	}
	
	$itemFound = false;
        foreach ($product as $item) {
            if ($item['ProductID'] == $id) {
                $itemFound = true;
                //echo '<h2>' . htmlspecialchars($item['Name']) . '</h2>';
                //echo '<p>Item Link: <a href="' . htmlspecialchars($item['ProductID']) . '">' . htmlspecialchars($item['ProductID']) . '</a></p>';
                //echo '<p><a href="edit.php?section=' . urlencode($item['Name']) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item['Name']) . '">Delete</a></p>';
                break; // Exit the loop once the item is found
            }
        }
	
	
    // Find the product with the specified ID

    /* foreach ($product as $p) {
        if ($p[0] == $productId) {
            $product = $p;
            break;
        }
    } */
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
</head>
<body>
    <h1>Product Details</h1>

    <?php if (isset($product)) { ?>
        <h2>Product Name: <?= $product[0]['Name'] ?></h2>
        <p>Description: <?= $product[0]['Description'] ?></p>
        <p>Application: <?= $product[0]['Applications'] ?></p>
		<p>icon: <?= $product[0]['Icon'] ?></p>

        <!-- Edit and Delete buttons -->
        <form method="post" action="edit.php?id=<?= $product[0]['ProductID'] ?>">
            <button type="submit">Edit</button>
        </form>

        <form method="post" action="delete.php?id=<?= $product[0]['ProductID'] ?>">
            <button type="submit">Delete</button>
        </form>
    <?php } else { ?>
        <p>Product uh not foundddddd.</p>
    <?php } ?>

    <p><a href="index.php">Back to Product List</a></p>
</body>
</html>