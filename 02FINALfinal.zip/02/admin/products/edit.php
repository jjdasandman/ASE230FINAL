<?php
// Include any necessary files and functions
//include '../../lib/ReadCSV.php';

// Retrieve data from your data source (e.g., CSV file)
//$csvFilePath = '../../data/products.csv'; 
//$products = ReadCSV($csvFilePath);
include '../../lib/db_connection.php';
$product = array();

// Check if the product ID is provided in the query parameters
//
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

	$id = $_GET['id'];
	$q =  $conn->prepare('SELECT ProductID, Name, Description, Applications, Icon FROM products WHERE ProductID = :id');
	$q->execute([':id' => $id]);
	while ($row = $q->fetch())
	{
		$product[] = $row;
	}
	echo '<pre>'; 
	print_r($product); 
	echo '</pre>';
    // Find the product with the specified ID
    /* $product = null;
    foreach ($product as $p) {
        if ($p[0] == $productId) {
            $product = $p;
            break;
        }
    } */
	//echo 'products: <br>';
	//print_R($product);
}

// Handle form submission for updating the product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Retrieve the product ID
    $productId = $_POST['id'];
	//echo 'productId: ' . $productId. "<br>";
	$updatedName = $_POST['name'];
	//echo 'updatedName: ' . $updatedName. "<br>";
    $updatedDesc = $_POST['description'];
	//echo 'updatedDesc: ' . $updatedDesc. "<br>";
	$updatedApp = $_POST['applications'];
	//echo 'updatedApp: ' . $updatedApp. "<br>";
	$updatedIcon = $_POST['icon'];
	//echo 'updatedIcon: ' . $updatedIcon. "<br>";
    // Retrieve and update the product details
	//echo 'product[0][ProductID]: ' . $product[0]['ProductID']. "<br>";
	//echo "<br>" . "updating query..." . "<br>";
	
	$updateQuery = $conn->prepare("UPDATE products SET Name = :updatedName, Description = :updatedDesc, Applications = :updatedApp, Icon = :updatedIcon WHERE ProductID = :productId");
	//UPDATE `pages` SET `Title` = 'Test31', `Content` = '#Test31' WHERE `pages`.`PageID` = 9;
	$updateQuery->bindParam(':updatedName', $updatedName);
	$updateQuery->bindParam(':updatedDesc', $updatedDesc);
	$updateQuery->bindParam(':updatedApp', $updatedApp);
	$updateQuery->bindParam(':updatedIcon', $updatedIcon);
	$updateQuery->bindParam(':productId', $productID);
	$productID = $product[0]['ProductID'];
	//$PageID = $items[2];
	//$productId = $product[0][0];
	$updateQuery->execute();   
	
	
	
	//print_r($products);
	//echo '<br>';
    // Update the product in the array
/* foreach ($products as $key => $p) {
    if ($p[0] == $productId) {
        $products[$key] = $updatedProduct;
        break;
    }
} */


    // Redirect to the detail page for the updated product
	
    header("Location: detail.php?id=" . urlencode($_POST['id']));
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>
 
    <?php if ($product) { ?>
        <form method="post" action="">
            <input type="hidden" name="update" value="true">
            <input type="hidden" name="id" value="<?= $product[0]['ProductID'] ?>">

            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?= $product[0]['Name'] ?>" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" required><?= $product[0]['Description'] ?></textarea>

            <label for="applications">Applications:</label>
            <textarea name="applications" id="applications" required><?= $product[0]['Applications'] ?></textarea>

            <label for="icon">Icon:</label>
            <input type="text" name="icon" id="icon" value="<?= $product[0]['Icon'] ?>" required> <!-- Include the icon input -->

            <input type="submit" value="Save Changes">
        </form>
    <?php } else { ?>
        <p>Product not found</p>
    <?php } ?>

    <p><a href="index.php">Back to Product List</a></p>
</body>
</html>