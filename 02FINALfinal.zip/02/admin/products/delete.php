<?php
// Include any necessary files and functions
//include '../../lib/ReadCSV.php'; 
include '../../lib/db_connection.php';
$items = array();
$id; //id will be the pageID to delete
echo "reading Query...". "<br>". "<br>"; 
$q =  $conn->prepare('SELECT ProductID, Name FROM products');
$q->execute();
while ($row = $q->fetch()){
	$items[] = $row; //this do the same thing; appending to the array
}
/* echo "<pre>";
   print_r($items);
echo "</pre>"; */
// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['id'])) {
    $requestedId = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
            // Read the contents of the CSV file into an array
            foreach($items as $item){
				//echo "product ID: " . $item['ProductID'] ."; looking for ID:" . $requestedId . "<br>";
				//echo "item[ProductID]: " . $item['ProductID'] . "<br>";
				if($item['ProductID'] == $requestedId){
				$id = $item['ProductID']; //setting the pageID of the sections that matches
				echo "identified ProductID: " . $id . "<br>";

			}
		}
			
        echo "<br>" . "deleting query..." . "<br>";
	
		$deleteQuery = $conn->prepare("DELETE FROM products WHERE ProductID = :requestedId");
		//DELETE FROM pages WHERE `pages`.`PageID` = 0
		$deleteQuery->bindParam(':requestedId', $requestedId);
		// delete one row
		//$requestedId = $id;
		$deleteQuery->execute();
		
		echo "Query deleted." . "<br>" . "<br>";


		// Redirect the user to the index page
        header('Location: index.php');
        exit; // Terminate the script
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Item</title>
</head>
<body>
    <h1>Delete Item</h1>
    <?php
    if (isset($requestedId)) {
        echo "Are you sure you want to delete the item with ID: $requestedId?";
    ?>
    <form method="post" action="">
        <label for="confirm">Confirm Deletion (type 'yes' to confirm):</label>
        <input type="text" name="confirm" id="confirm">
        <input type="submit" value="Delete">
    </form>
    <?php
    } else {
        echo 'Item not found.';
    }
    ?>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>