<?php
// Include any necessary files and functions 
//include '../../lib/ReadCSV.php';
include '../../lib/db_connection.php';
$items = array();
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $name1 = $_POST['name'];
	echo "name: " . $name1. "<br>";
    $description1 = $_POST['description'];
	echo "description: " . $description1. "<br>";
    $application1 = $_POST['application'];
	echo "application: " . $application1. "<br>";
	$icon1 = $_POST['icon'];
	echo "icon: " . $icon1. "<br>";

    // Validate the form fields (you can add more validation as needed)
    if (empty($name1) || empty($description1) || empty($application1) || empty($icon1)) {
        echo 'All fields are required.';
        exit; // Terminate the script
    }

    echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT productID FROM products');
	$q->execute();
	while ($row = $q->fetch())
	{
	$items[] = $row['productID']; //this and 
	
	}
	$appendToID = max($items) + 1;
	echo "Append to ID: " . $appendToID . "<br>";
	echo "inserting...". "<br>";
	/*
	$insertQuery = $conn->prepare("INSERT INTO products (productID, name, description, applications, icon) VALUES (:appendToID, :name1, :description1, :applications1, :icon1)");
	//$insertQuery->bindParam(':productID', $appendToID);
	$insertQuery->bindParam(':name', $name1);
	$insertQuery->bindParam(':description', $description1);
	$insertQuery->bindParam(':applications', $applications1);
	$insertQuery->bindParam(':icon', $icon1);
	// insert one row
	//$PageID1 = $appendToID;

	$insertQuery->execute(); */
	$Name = $name1;
	$Description = $description1;
	$Applications = $application1;
	$Icon = $icon1;
	$q = $conn->prepare("INSERT INTO products (ProductID, Name, Description, Applications, Icon) VALUES (:ProductID, :Name, :Description, :Applications, :Icon)");
	$q->bindParam(':ProductID', $ProductID);
	$q->bindParam(':Name', $Name);
	$q->bindParam(':Description', $Description); 
	$q->bindParam(':Applications', $Applications);
	$q->bindParam(':Icon', $Icon);
	$ProductID = $appendToID;

	$q->execute();
	echo "Insertion Complete.". "<br>". "<br>";
    
	
    // Redirect the user to the edit page for the newly created item
    header('Location: edit.php?id=' . urlencode($newItem[0]));
    exit; // Terminate the script
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Item</title>
</head>
<body>
     <h1>Create New Item</h1>
    <form method="POST" action="">
        <!-- Form fields for creating a new item -->
        <label for="name">Name:</label>
        <input type="text" name="name" id="name1" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description1" required></textarea>

        <label for="application">Application:</label>
        <textarea name="application" id="application1" required></textarea>
		
        <label for="icon">Icon:</label>
        <input type="text" name="icon" id="icon1" required>

        <input type="submit" value="Create Item">
    </form>
    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>