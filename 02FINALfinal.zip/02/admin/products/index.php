<?php
// Include any necessary files and functions
include_once '../../lib/db_connection.php';
$data = array();


echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT productID, name, description, applications, icon FROM products');
$q->execute();
while ($row = $q->fetch())
{
	$data[] = $row; //['title']; //this and 
	//array_push($data, $row['content']); //this do the same thing; appending to the array
	
}
?> 

<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
</head>
<body>
    <h1>Product List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Product</th>
                <th>Description</th>
                <th>Applications</th>
                <th>Icon</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $product) { 
					echo '<tr>';
                    echo '<td>' . htmlspecialchars($product['name']) . '</td>'; 
					echo '<td>' . htmlspecialchars($product['description']) . '</td>';
					echo '<td>' . htmlspecialchars($product['applications']) . '</td>';
					echo '<td>' . htmlspecialchars($product['icon']) . '</td>';
                    echo '<td><a href="detail.php?id=' . urlencode($product['productID']) . '">View Details</a></td>';
					// urlencode($_POST['id']))
                    echo '</tr>';
			} ?>
        </tbody>
		
    </table>
    <p><a href="create.php">Create New Product</a></p>
	<p><a href="../dashboard.php">
	<button type="button" class="#">return to dashboard</button>
	</a></p>
</body>
</html>