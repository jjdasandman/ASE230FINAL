<?php
// Include any necessary files and functions
//include '../../lib/CSVHelper.php';
// Include the database connection file
include '../../lib/db_connection.php';
$existingLink = '';
$items = array();
// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];

    // Specify the path to your CSV file
    //$csvFilePath = '../../data/navbar.csv';

    // Load the items from the CSV file
    //$items = CSVHelper::readCSV($csvFilePath);
	// Load the items from the database
    //$requestedSection = "home";
	echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT title, content, pageID FROM pages WHERE Title = :requestedSection');
	$q->execute([':requestedSection' => $requestedSection]);
	while ($row = $q->fetch())
	{
	$items[] = $row['title']; //this and 
	array_push($items, $row['content']); //this do the same thing; appending to the array
	$items[] = $row['pageID'];

	}

	
    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Process and validate the form data
        $updatedSection = $_POST['section'];
        $updatedLink = $_POST['link'];

        // Update the requested item using CSVHelper
        //CSVHelper::updateEntry($requestedSection, $updatedSection, $updatedLink);
		// Update the requested item using a SQL UPDATE query
		echo "<br>" . "updating query..." . "<br>";
	
		$updateQuery = $conn->prepare("UPDATE pages SET Title = :updatedSection, Content = :updatedLink WHERE PageID = :PageID");
		//UPDATE `pages` SET `Title` = 'Test31', `Content` = '#Test31' WHERE `pages`.`PageID` = 9;
		$updateQuery->bindParam(':updatedSection', $updatedSection);
		$updateQuery->bindParam(':updatedLink', $updatedLink);
		$updateQuery->bindParam(':PageID', $PageID);
		$PageID = $items[2];
		$updateQuery->execute();

        // Redirect to the index page
        header('Location: index.php');
        exit;
    }
}

// Check if the requested item is found and display the form for editing
 if (isset($requestedSection) && $requestedSection) {
    // Display the form for editing the item with pre-filled values
    if ($items[0] === $requestedSection) {
		$existingLink = $items[1];
    } 


?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
</head>
<body>
    <h1>Edit Item</h1>
    <form method="POST" action="">
        <!-- Form fields for editing the item -->
        <label for="section">Item Name:</label>
        <input type="text" name="section" id="section" value="<?php echo $requestedSection; ?>" required>

        <label for="link">Item Link:</label>
        <!-- You can populate the "link" field with the existing link value here -->
        <input type="text" name="link" id="link" value="<?php echo $existingLink; ?>" required>

        <input type="submit" value="Save Changes">
    </form>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>
<?php
} else {
    // Handle the case where the requested item is not found
    echo 'Item not found.';
}
?>