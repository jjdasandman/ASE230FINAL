<?php
/* PAGES INDEX */
/* include '../../lib/CSVHelper.php'; // Include the CSVHelper class file
$data = CSVHelper::readCSV('../../data/navbar.csv');
echo '<pre>'; 
	print_r($data); 
	echo '</pre>'; */
include_once '../../lib/db_connection.php';
$data = array();


echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT title, content FROM pages');
$q->execute();
while ($row = $q->fetch())
{
	$data[] = $row; //['title']; //this and 
	//array_push($data, $row['content']); //this do the same thing; appending to the array
	
} 


/* if (!empty($data) && isset($data[0])) {
    // Skip the first row (header)
    array_shift($data);
} */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pages Item List</title>
</head>
<body>
    <h1>Item List</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Item Name</th>
				<th>Link</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Item rows will be generated dynamically here -->
            <?php
            // Loop through the items and generate table rows
            if (!empty($data)) {
                foreach ($data as $item) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($item['title']) . '</td>'; // Use $item[0] for "section"
					echo '<td>' . htmlspecialchars($item['content']) . '</td>';
                    echo '<td><a href="detail.php?section=' . urlencode($item['title']) . '">View Details</a></td>';
                    echo '</tr>';
                }
            } else {
                // Handle the case where $data is empty (no CSV data found)
                echo '<tr><td colspan="2">No data found.</td></tr>';
            }
            ?>
        </tbody>
    </table>
    <p><a href="create.php">
        <button type="button" class="#">click to create</button>
    </a></p>
    <p><a href="../dashboard.php">
        <button type="button" class="#">return to dashboard</button>
    </a></p>
</body>
</html>