<?php
// Include any necessary files and functions
//include '../../lib/CSVHelper.php';
 
// Specify the path to your CSV file
//$csvFilePath = '../../data/navbar.csv';
include '../../lib/db_connection.php';
$items = array();
$d; //d will be the pageID to delete
echo "reading Query...". "<br>". "<br>"; 
	$q =  $conn->prepare('SELECT pageID, title FROM pages');
	$q->execute();
	while ($row = $q->fetch())
	{
	$items[] = $row; //this do the same thing; appending to the array

	}

// Check if a specific item is requested (e.g., based on query parameters)
if (isset($_GET['section'])) {
    $requestedSection = $_GET['section'];

    // Check if the user has confirmed the deletion
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        // Use CSVHelper to delete the entry
       // CSVHelper::deleteEntry($requestedSection);
	   	foreach($items as $item){
				echo "item Title: " . $item['title'] ."; looking for section:" . $requestedSection . "<br>";
			if($item['title'] === $requestedSection){
				$d = $item['pageID']; //setting the pageID of the sections that matches
				echo "identified pageID: " . $d . "<br>";
			}
		}
		echo "<br>" . "deleting query..." . "<br>";
	
		$deleteQuery = $conn->prepare("DELETE FROM pages WHERE PageID = :PageID");
		//DELETE FROM pages WHERE `pages`.`PageID` = 0
		$deleteQuery->bindParam(':PageID', $PageID);
		// delete one row
		$PageID = $d;
		$deleteQuery->execute();
		
		echo "Query deleted." . "<br>" . "<br>";

        // Redirect the user to the index page
        header('Location: index.php');
        exit; // Terminate the script
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Item</title>
</head>
<body>
    <h1>Delete Item</h1>

    <?php
    // Display a confirmation message and form for deletion
    if (isset($requestedSection)) {
        echo "Are you sure you want to delete the item with section: $requestedSection?";
    ?>
    <form method="post" action="">
        <label for="confirm">Confirm Deletion (type 'yes' to confirm):</label>
        <input type="text" name="confirm" id="confirm">
        <input type="submit" value="Delete">
    </form>
    <?php
    } else {
        echo 'Item not found.';
    }
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>