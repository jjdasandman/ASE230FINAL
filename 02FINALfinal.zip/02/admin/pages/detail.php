<?php
// Include any necessary files and functions
/* include '../../lib/ReadCSV.php';
// Retrieve data from your data source (e.g., CSV, database)
$data = ReadCSV('../../data/navbar.csv');

// Check if there's data available
if (!empty($data) && isset($data[0])) {
    // Skip the first row (header)
    array_shift($data);
} */

include_once '../../lib/db_connection.php';
$data = array();

echo "reading Query...". "<br>". "<br>"; 
$q = $conn->prepare('SELECT title, content FROM pages');
$q->execute();
while ($row = $q->fetch())
{
	//echo $row['title'] . "<br>";
	//echo $row['content'] . "<br>";
	$data[] = $row; 
	
}
 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Item Details</title>
</head>
<body>
    <h1>Item Details</h1>

    <?php
    // Check if a specific item is requested (e.g., based on query parameters)
    if (isset($_GET['section'])) {
        $requestedSection = $_GET['section'];

        // Find and display the details of the requested item
        $itemFound = false;
        foreach ($data as $item) {
            if ($item['title'] === $requestedSection) {
                $itemFound = true;
                echo '<h2>' . htmlspecialchars($item['title']) . '</h2>';
                echo '<p>Item Link: <a href="' . htmlspecialchars($item['content']) . '">' . htmlspecialchars($item['content']) . '</a></p>';
                echo '<p><a href="edit.php?section=' . urlencode($item['title']) . '">Edit</a> | <a href="delete.php?section=' . urlencode($item['title']) . '">Delete</a></p>';
                break; // Exit the loop once the item is found
            }
        }

        if (!$itemFound) {
            echo '<p>Item not found.</p>';
        }
    } else {
        echo '<p>No item selected.</p>';
    }
    ?>

    <p><a href="index.php">Back to Item List</a></p>
</body>
</html>