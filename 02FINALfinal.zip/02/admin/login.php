<?php
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize user input
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];

    // Specify the path to the CSV file
    $csvFilePath = '../data/passwords.csv';

    // Check if the username and password match any entries in the CSV file
    if (($handle = fopen($csvFilePath, "r")) !== false) {
        while (($data = fgetcsv($handle, 1000, ",")) !== false) {
            list($storedUsername, $hashedPassword) = $data;

            if ($username === $storedUsername && password_verify($password, $hashedPassword)) {
                // Valid login; store the username in the session
                $_SESSION['username'] = $username;

                // Redirect to the dashboard or another destination
                header('Location: dashboard.php');
                exit;
            }
        }
        fclose($handle);
    }

    // Invalid login; display an error message
    $error = "Invalid username or password.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <input type="submit" value="Login">
    </form>

    <p>Don't have an account? <a href="register.php">Register</a></p>
	<p>or <a href="../index.php">
	<button type="button" class="#">return to homepage</button>
	</a></p>

    <?php
    if (isset($error)) {
        echo '<p style="color: red;">' . $error . '</p>';
    }
    ?>
</body>
</html>