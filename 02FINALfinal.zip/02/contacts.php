<?php
// Include any necessary files and functions
include 'lib/ReadCSV.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process and validate the form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $comments = $_POST['comments'];

    // Validate the form fields (you can add more validation as needed)
    if (empty($name) || empty($email) || empty($comments)) {
        echo 'All fields are required.';
        exit; // Terminate the script
    }

    // Prepare the data for the new contact request as an array
    $newRequest = [$name, $email, $subject, $comments];

    // Specify the path to your CSV file
    $csvFilePath = 'data/contacts.csv';

    // Open the CSV file in append mode
    $csvFile = fopen($csvFilePath, 'a');

    // Lock the file for writing
    if (flock($csvFile, LOCK_EX)) {
        // Write the new contact request to the CSV file
        fputcsv($csvFile, $newRequest);

        // Release the lock
        flock($csvFile, LOCK_UN);

        // Close the file
        fclose($csvFile);
    } else {
        // Handle the case where the file could not be locked (e.g., concurrent access)
        echo 'Unable to add the new contact request at this time. Please try again later.';
        exit; // Terminate the script
    }

    // Redirect the user to a thank-you page or back to the contact form
    header('Location: thankyou.php');
    exit; // Terminate the script
}
?>